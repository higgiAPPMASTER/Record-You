const fs = require("fs");
const path = require("path");
const JSZip = require("/home/runner/workspace/artifacts/music-recorder/node_modules/jszip");

const EXCLUDE_DIRS = new Set(["node_modules", ".git", "dist", ".pnpm-store", ".local", "__pycache__", ".cache", ".config"]);
const EXCLUDE_FILES = new Set(["pnpm-lock.yaml", "record-you-project.tar.gz", "record-you-project.zip"]);
const EXCLUDE_DOT = new Set([".gitignore", ".env.example", ".nvmrc", ".node-version"]);
const ROOT = "/home/runner/workspace";

const zip = new JSZip();
let count = 0;

function addDir(dirPath, zipPath) {
  let entries;
  try { entries = fs.readdirSync(dirPath, { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    if (EXCLUDE_DIRS.has(entry.name)) continue;
    if (EXCLUDE_FILES.has(entry.name)) continue;
    if (entry.name.startsWith(".") && !EXCLUDE_DOT.has(entry.name)) continue;
    const full = path.join(dirPath, entry.name);
    const zp = zipPath ? `${zipPath}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      addDir(full, zp);
    } else {
      try {
        const buf = fs.readFileSync(full);
        zip.file(`record-you/${zp}`, buf);
        count++;
      } catch { /* skip */ }
    }
  }
}

addDir(ROOT, "");
console.log(`Added ${count} files. Generating zip...`);

zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE", compressionOptions: { level: 6 } })
  .then((buf) => {
    fs.writeFileSync("/home/runner/workspace/record-you-project.zip", buf);
    console.log(`Done: ${(buf.length / 1024 / 1024).toFixed(1)} MB`);
  });
